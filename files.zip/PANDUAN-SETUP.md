# Panduan Setup — Absensi Digital (v2, dengan Firebase Auth per Karyawan)

## 1. File yang perlu di-upload bareng
Upload ke root repo GitHub Pages Anda (satu folder yang sama):
- `index.html`
- `manifest.json`
- `service-worker.js`
- `icon-192.png`
- `icon-512.png`

Kalau file-file ini terpisah folder, ikon home-screen & mode offline tidak akan jalan.

## 2. Buat project Firebase
1. https://console.firebase.google.com → **Add project**.
2. Aktifkan **Firestore Database** (mode production).
3. Aktifkan **Authentication → Sign-in method → Email/Password**.
4. Di **Project Settings → Your apps**, tambahkan Web App, salin config ke bagian atas `<script>` di `index.html` (ganti semua nilai `GANTI_...`).

## 3. Buat akun Bos/Atasan
1. **Authentication → Users → Add user**, isi email & password bos (mis. `bos@instansi.com`).
2. Salin **User UID** yang muncul.
3. Buka **Firestore Database → Start collection** → beri nama collection `admins` → Document ID = **UID tadi** → tambah field apa saja, misalnya `email: "bos@instansi.com"` → Save.

Tanpa langkah #3 ini, akun bos bisa login tapi dashboard admin akan tetap kosong/ditolak oleh security rules.

## 4. Pasang Firestore Security Rules
Buka **Firestore → Rules**, ganti semuanya dengan ini:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    function isAdmin(){
      return request.auth != null && exists(/databases/$(database)/documents/admins/$(request.auth.uid));
    }
    function isOwner(uid){
      return request.auth != null && request.auth.uid == uid;
    }

    match /admins/{uid} {
      allow read: if isAdmin();
      allow write: if false; // hanya ditambah manual lewat Firebase Console
    }

    match /employees/{uid} {
      allow read: if isOwner(uid) || isAdmin();
      allow create, update, delete: if isAdmin();
    }

    match /attendance/{uid}/days/{date} {
      allow read: if isOwner(uid) || isAdmin();
      allow create, update: if isOwner(uid) || isAdmin();
      allow delete: if isAdmin();
    }

    match /settings/{docId} {
      allow read: if true;
      allow write: if isAdmin();
    }

    match /messages/{uid}/chat/{msgId} {
      allow read: if isOwner(uid) || isAdmin();
      allow create: if isAdmin();
      allow update: if isOwner(uid); // dipakai karyawan untuk tandai "dibaca"
      allow delete: if isAdmin();
    }
  }
}
```

## 5. Buat index untuk laporan & monitoring
Tab **Monitoring** dan **Laporan** memakai *collection group query* ke subcollection `days`. Firestore akan menolak query ini sampai index-nya dibuat. Cara termudah:
1. Jalankan dashboard admin → buka tab Monitoring atau Laporan.
2. Firestore akan melempar error di console browser (F12) berisi **link langsung** untuk membuat index — klik link itu, lalu klik "Create Index" di Firebase Console.
3. Tunggu beberapa menit sampai status index "Enabled", lalu reload dashboard.

(Atau buat manual: **Firestore → Indexes → Composite → Collection group scope, collection `days`, field `date` Ascending**.)

## 6. Struktur data Firestore (v2)
- `employees/{uid}` — `{ empId, name, position, phone, active }` — `uid` = Firebase Auth UID milik karyawan tersebut
- `admins/{uid}` — penanda admin, dibuat manual di Console
- `settings/office` — `{ name, lat, lng, radius, jamPagi, toleransiTelat, jamIstirahatMulai, jamIstirahatSelesai, jamPulang, jamMangkir }`
- `attendance/{uid}/days/{yyyy-mm-dd}` — `{ empId, empName, date, pagi, istirahatKeluar, istirahatMasuk, pulang, lemburMulai, lemburSelesai }`
- `messages/{uid}/chat/{msgId}` — `{ from:'admin', text, timestamp, read }`

## 7. Cara kerja login karyawan sekarang
- Karyawan tetap login pakai **ID Karyawan + Kode Akses**, tampilannya sama seperti sebelumnya.
- Di baliknya, ID diubah jadi email sintetis (`emp001@absensi.local`) dan Kode Akses jadi password Firebase Auth asli — jadi kena semua proteksi bawaan Firebase: password ter-hash, ada rate-limit otomatis kalau salah berkali-kali (`auth/too-many-requests`).
- Saat admin menambah karyawan baru, akun Firebase Auth dibuat otomatis di belakang layar (pakai instance Firebase kedua supaya sesi login admin tidak ikut ter-switch).

## 8. Yang berubah soal keamanan (dan yang masih jadi batasan)

**Sudah lebih aman dari versi sebelumnya:**
- PIN karyawan tidak lagi tersimpan sebagai teks polos yang bisa dibaca siapa saja — sekarang di-hash oleh Firebase Auth.
- Data `employees` tidak lagi bisa dibaca publik tanpa login (rules membatasi per-uid).
- Ada rate-limit otomatis anti brute-force dari Firebase saat percobaan login gagal berkali-kali.
- Setiap karyawan hanya bisa baca/tulis data absensi & chat miliknya sendiri (bukan milik karyawan lain), karena rules dikunci per-UID.

**Masih jadi batasan (konsekuensi dari pilihan "tanpa Cloud Functions"):**
- **Waktu & lokasi absen masih dipercaya dari perangkat karyawan.** Orang yang paham developer tools browser secara teknis bisa memalsukan jam HP atau koordinat GPS sebelum submit. Untuk menutup celah ini sepenuhnya, waktu & lokasi perlu divalidasi ulang di server (Cloud Function) — ini yang tadi saya tawarkan sebagai opsi kedua. Kalau ke depannya butuh, tinggal bilang, terutama karena Anda sudah proses upgrade ke Blaze plan untuk sistem billing.
- **Admin tidak bisa mengganti Kode Akses karyawan yang lupa PIN** langsung dari dashboard (butuh Admin SDK/Cloud Function untuk itu). Solusinya sementara: nonaktifkan ID lama, buat ID baru untuk karyawan tersebut.
- **Menghapus karyawan dari dashboard hanya menghapus profil & akses**, bukan akun Firebase Auth-nya secara utuh. Ini aman secara fungsional (karyawan yang dihapus tidak bisa absen lagi karena sistem cek profil di Firestore), tapi kalau mau benar-benar bersih, hapus manual juga di **Firebase Console → Authentication → Users**.
- Foto selfie masih tersimpan sebagai base64 di dalam dokumen Firestore (bukan Cloud Storage terpisah) — cukup aman selama rules di atas terpasang benar (hanya admin & pemilik data yang bisa baca), tapi akan menambah ukuran/biaya baca Firestore seiring jumlah karyawan & lama pemakaian.
- Aktifkan **2-Step Verification** untuk akun Google/Firebase milik bos sendiri, supaya akun admin instansi tidak gampang diambil alih.

## 9. Deploy ke GitHub Pages
1. Push semua file (lihat bagian 1) ke repo, misal `rifkyanhar/absensi-digital`.
2. Settings → Pages → Branch `main` / folder root → Save.
3. **Authentication → Settings → Authorized domains** di Firebase Console → tambahkan domain GitHub Pages Anda (`rifkyanhar.github.io`), kalau tidak, semua login (admin maupun karyawan) akan gagal.

## 10. Install sebagai aplikasi di HP
- **Android (Chrome)**: buka link situs → menu titik tiga → "Add to Home screen" / "Install app".
- **iPhone (Safari)**: buka link → tombol Share → "Add to Home Screen".
- Setelah itu ikon aplikasi (icon mint dengan centang) muncul di home screen, dan halaman shell-nya (HTML/CSS/JS) tetap bisa dibuka walau sinyal lemah — data absensi yang gagal terkirim otomatis diantre lalu disinkron begitu online kembali.

## 11. Checklist sebelum serah terima ke klien
- [ ] Config Firebase sudah diganti di `index.html`
- [ ] Akun bos dibuat + UID-nya didaftarkan di collection `admins`
- [ ] Security Rules bagian 4 sudah dipasang
- [ ] Index collection group `days` sudah aktif (bagian 5)
- [ ] Lokasi kantor & radius geofence sudah diatur dari tab Geofence
- [ ] Jam kerja & toleransi telat sudah diatur
- [ ] Minimal 1 karyawan dummy dites end-to-end (login → absen → cek muncul di Monitoring)
- [ ] Domain GitHub Pages sudah masuk Authorized domains
- [ ] Sudah dicoba "Add to Home Screen" di Android & iPhone
